def main():
    today = "Monday"
    print("Today is", today, ".")

main()