for i, item in enumerate(['a', 'b', 'c'], 1):
    print(i, item, sep='. ')