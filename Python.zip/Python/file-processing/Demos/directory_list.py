import os
dir_contents = os.listdir("my_files")
for item in dir_contents:
    print(item)