x = 0

def set_x():
    global x
    x = 1

def get_x():
    print(x)

def main():
    set_x()
    get_x()

main()