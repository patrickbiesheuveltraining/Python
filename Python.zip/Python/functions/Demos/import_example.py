import add_nums_with_return

total = add_nums_with_return.add_nums(1, 2, 3, 4, 5)
print(total)