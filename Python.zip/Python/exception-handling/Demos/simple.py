try:
    1/0
except:
    print('You cannot divide by zero!')