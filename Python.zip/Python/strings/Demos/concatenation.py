user_name = input("What is your name? ")
greeting = "Hello, " + user_name + "!"
print(greeting)