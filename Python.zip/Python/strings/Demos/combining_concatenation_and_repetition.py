flower = input("What is your favorite flower? ")
reply = "A " + flower + (" is a " + flower) * 2 + "."
print(reply)