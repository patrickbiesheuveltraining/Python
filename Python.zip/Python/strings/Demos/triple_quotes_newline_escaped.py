print("""We're knights of the Round Table, \
we dance whene'er we're able.
We do routines and chorus scenes \
with footwork impeccable,
We dine well here in Camelot, \
we eat ham and jam and Spam a lot.""")