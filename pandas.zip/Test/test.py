import pandas as pd
import numpy as np
from datetime import date

def vier_decimalen(x):
    return round(x,2)

def test():
    return 'testing'
    

path_mobile = r'test.csv'
path_output = r'output.csv'

mobile = pd.read_csv(path_mobile,sep=';',encoding='utf-8')
testcolumn = list(range(0,2184))
#TWEE MANIER OM EEN KOLOM TOE TE VOEGEN
#mobile['Test'] = testcolumn
mobile.insert(2,"test",testcolumn)

#MEERDERE MANIEREN OM WAARDEN AAN TE PASSEN
mobile['price'].update(mobile['price'].apply(vier_decimalen))
#mobile['additional_text'].fillna('',inplace=True)
#mobile['use_service_value'].fillna('',inplace=True)
mobile.fillna('',inplace=True)

mobile['attribute_set'] = mobile['attribute_set'].str.strip() #LEADING, LAGGING SPATIES WEGHALEN


#filterdf = mobile[mobile['additional_text']=='hallo']
#filterdf['use_service_value'].update('dag')
#mobile.loc[mobile['additional_text']=='hallo', 'use_service_value']=test()
#mobile['use_service_value'] = np.where(mobile['additional_text']=='hallo','AAA','BBB')

print(mobile)
mobile.to_csv(path_output, index=False, header=True, sep=';',encoding='utf-8')

#accessoire_df = mobile.loc[mobile['price'] >= 100]
#print(accessoire_df)
'''
print(vier_decimalen(3.45456544))
print(vier_decimalen(3.4))
print(vier_decimalen(3))
print(vier_decimalen(3.44544))
print('{:.2f}'.format(3.445))
'''

#1. column toevoegen met iets
#2. 
#today = date.today()
#print(today)